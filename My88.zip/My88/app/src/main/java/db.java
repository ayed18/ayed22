import android.view.View;
import android.widget.Toast;

import com.example.my88.R;

public class db {
db =  new db.java(this);
protected void onCreate (Bundle savedinstanceState){
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_m88);
    final EditText name = (EditText)findViewById(R.id.textView2);
            Button btn = (Button)findViewById(R.id.button2);
    btn.setOnClickListener((view)
    String name = name.getText().toString();
    boolean result = Db.insertData(name);
    if(result== true){
        Toast.makeText(db.this,"تم اضافة البيانات"toast)

    }
}};